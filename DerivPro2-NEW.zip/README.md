# DerivPro2 — Live Market Analyzer

A free static website for GitHub Pages using Deriv's public WebSocket API. It shows real market ticks, a line chart, EMA 9, EMA 21, RSI 14, and descriptive last-digit statistics for Over/Under and Matches/Differs. Rise/Fall bias is a technical estimate, not a guaranteed prediction. **No trades are placed.**

## Upload on iPhone

1. Download and unzip the provided ZIP using the iPhone Files app.
2. Open your GitHub repository `DerivPro2` in Safari.
3. Choose **Add file → Upload files** (on small screens, try Safari's Request Desktop Website option).
4. Upload the four files **index.html**, **styles.css**, **app.js**, **README.md** directly to the repository root, replacing old versions if necessary. Do not upload the enclosing folder or the ZIP itself.
5. Commit the changes to the `main` branch.
6. Go to **Settings → Pages** and select **Deploy from a branch → main → /(root)**, then Save.
7. Go to **Actions** and wait for a successful Pages deployment. Return to Pages and tap **Visit site**. The URL usually looks like `https://YOUR-USERNAME.github.io/DerivPro2/` (repository path is case-sensitive).

## Connection troubleshooting

- The header must change from Connecting to Connected. Market choices should appear and prices should move.
- Try Refresh, reload Safari, and verify internet access. Check the status text for API errors.
- The sample public Deriv app ID in `app.js` is `1089`. If Deriv rejects it or requires your own registered app, create a free app in the Deriv developer dashboard and replace the `APP_ID` constant.
- Some networks block WebSockets. Try a different Wi-Fi/mobile connection.
- This is a **public, read-only** connection. Never paste your Deriv password or API token into GitHub files.

## Important limitations

- Market availability is determined by the Deriv API. It may change.
- The chart and EMA/RSI currently use **tick history**, not time-based candles. The timeframe selector is informational until candle aggregation is implemented.
- Last-digit percentages describe observed ticks; they do not predict the next tick. Matches/Differs and Over/Under are descriptive statistics, not contract win probabilities.
- Historical Rise/Fall signals are generated from incoming data only, not independently backtested trade results.
- API availability and the public app ID cannot be guaranteed from this offline package; verify live connection on the published website.
