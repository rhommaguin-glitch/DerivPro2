/* Deriv public market data API. No account, tokens, orders or fake prices. */
(() => {
  'use strict';
  const API = 'wss://api.derivws.com/trading/v1/options/ws/public';
  const $ = id => document.getElementById(id);
  const state = { ws:null, market:'', markets:[], ticks:[], pending:null, results:[], reconnectTimer:null, generation:0, attempts:0, connected:false };
  const storageKey='derivpro2-real-outcomes-v1';
  try { state.results=JSON.parse(localStorage.getItem(storageKey)||'[]'); if(!Array.isArray(state.results))state.results=[]; }catch{state.results=[];}
  for(let i=0;i<10;i++){const o=document.createElement('option');o.value=i;o.textContent=i;$('target').appendChild(o);}
  $('target').value='5';
  function setStatus(message,live=false){$('status').textContent=message;$('status').className='status'+(live?' live':'');}
  function send(payload){if(state.ws?.readyState===WebSocket.OPEN)state.ws.send(JSON.stringify(payload));}
  function connect(){
    clearTimeout(state.reconnectTimer);state.generation++;const gen=state.generation;
    if(state.ws){state.ws.onclose=null;state.ws.close();}
    state.connected=false;setStatus('Connecting to Deriv…');$('error').textContent='';
    try{const ws=new WebSocket(API);state.ws=ws;
      ws.onopen=()=>{if(gen!==state.generation)return;state.connected=true;state.attempts=0;setStatus('Connected • waiting for ticks');send({active_symbols:'brief',req_id:1});if(state.market)subscribe();};
      ws.onmessage=event=>{if(gen!==state.generation)return;let d;try{d=JSON.parse(event.data);}catch{return;}
        if(d.error){$('error').textContent='Deriv API: '+d.error.message;return;}
        if(d.msg_type==='active_symbols')loadMarkets(d.active_symbols||[]);
        if(d.msg_type==='tick' && d.tick?.symbol===state.market)onTick(d.tick);
      };
      ws.onerror=()=>{$('error').textContent='Connection error. Check internet access or try Reconnect.';};
      ws.onclose=()=>{if(gen!==state.generation)return;state.connected=false;setStatus('Disconnected • retrying');state.reconnectTimer=setTimeout(connect,Math.min(30000,2000*2**Math.min(state.attempts++,4)));};
    }catch(e){$('error').textContent=e.message;state.reconnectTimer=setTimeout(connect,5000);}
  }
  function loadMarkets(symbols){
    const synthetic=symbols.filter(s=>{const c=String(s.market||'').toLowerCase(),sub=String(s.submarket||'').toLowerCase(),n=String(s.display_name||'').toLowerCase();return c.includes('synthetic')||c.includes('derived')||sub.includes('synthetic')||n.includes('volatility')||n.includes('boom')||n.includes('crash')||n.includes('step index')||n.includes('range break');});
    state.markets=(synthetic.length?synthetic:symbols).filter(s=>s.symbol && s.exchange_is_open!==0);
    const old=state.market;$('market').replaceChildren();
    state.markets.forEach(s=>{const o=document.createElement('option');o.value=s.symbol;o.textContent=s.display_name||s.symbol;$('market').appendChild(o);});
    if(!state.markets.length){$('error').textContent='No available markets returned by Deriv.';return;}
    const preferred=state.markets.find(s=>s.symbol==='R_75')?.symbol;
    state.market=state.markets.some(s=>s.symbol===old)?old:(preferred||state.markets[0].symbol);
    $('market').value=state.market;subscribe();
  }
  function subscribe(){if(!state.market)return;state.ticks=[];state.pending=null;render();send({forget_all:'ticks'});send({ticks:state.market,subscribe:1});setStatus('Subscribed • waiting for ticks',state.connected);}
  function onTick(t){
    const price=Number(t.quote);if(!Number.isFinite(price))return;
    const decimals=Number.isInteger(Number(t.pip_size))?Number(t.pip_size):2;
    const digit=Number(price.toFixed(Math.max(0,Math.min(10,decimals))).slice(-1));
    const entry={price,digit,time:Number(t.epoch)||Math.floor(Date.now()/1000),decimals};
    const prev=state.ticks[state.ticks.length-1];
    if(prev&&prev.time===entry.time&&prev.price===entry.price)return;
    if(state.pending){const p=state.pending;const win=p.side==='RISE'?price>p.entry:price<p.entry;
      state.results.unshift({time:new Date(entry.time*1000).toLocaleTimeString(),market:p.market,side:p.side,entry:p.entry.toFixed(p.decimals),actual:price.toFixed(decimals),win});
      state.results=state.results.slice(0,300);try{localStorage.setItem(storageKey,JSON.stringify(state.results));}catch{}state.pending=null;
    }
    state.ticks.push(entry);if(state.ticks.length>200)state.ticks.shift();
    // Deliberately simple, testable rule: last 5 tick net movement predicts next tick.
    if(state.ticks.length>=6){const start=state.ticks[state.ticks.length-6].price;const delta=price-start;if(delta!==0)state.pending={side:delta>0?'RISE':'FALL',entry:price,decimals,market:state.market};}
    setStatus('Live • receiving real Deriv ticks',true);render();
  }
  function render(){
    const a=state.ticks,last=a[a.length-1];$('price').textContent=last?last.price.toFixed(last.decimals):'—';$('digit').textContent=last?last.digit:'—';$('count').textContent=a.length;
    $('ticks').replaceChildren();if(!a.length)$('ticks').textContent='Waiting for real ticks…';
    a.slice(-15).reverse().forEach(t=>{const el=document.createElement('span');el.className='tick';el.textContent=t.price.toFixed(t.decimals)+' ['+t.digit+']';$('ticks').appendChild(el);});
    $('direction').textContent=state.pending?'Next tick prediction: '+state.pending.side+' (unverified until next tick)':'Waiting for 6 ticks / a non-flat momentum signal…';
    const n=state.results.length,w=state.results.filter(r=>r.win).length;$('total').textContent=n;$('wins').textContent=w;$('accuracy').textContent=n?(100*w/n).toFixed(1)+'%':'—';
    const digits=a.slice(-50).map(t=>t.digit),len=digits.length;
    if(!len){$('stats').textContent='Waiting for ticks…';$('matches').textContent='—';}
    else{const even=digits.filter(x=>x%2===0).length,over=digits.filter(x=>x>5).length,under=digits.filter(x=>x<5).length,five=digits.filter(x=>x===5).length;
      $('stats').textContent=`Last ${len} ticks: Even ${even}, Odd ${len-even} • Over 5: ${over}, Under 5: ${under}, Equal 5: ${five}`;
      const target=Number($('target').value),match=digits.filter(x=>x===target).length;
      $('matches').textContent=`Digit ${target}: Matches ${match} / Differs ${len-match} (observed sample only)`;
    }
    const body=$('history');body.replaceChildren();if(!n){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=5;td.textContent='No predictions recorded yet.';tr.appendChild(td);body.appendChild(tr);}
    state.results.slice(0,40).forEach(r=>{const tr=document.createElement('tr');[r.time,r.market,r.side,r.actual,r.win?'Win':'Loss'].forEach((v,i)=>{const td=document.createElement('td');td.textContent=v;if(i===4)td.className=r.win?'win':'loss';tr.appendChild(td);});body.appendChild(tr);});
  }
  $('market').addEventListener('change',e=>{state.market=e.target.value;subscribe();});
  $('target').addEventListener('change',render);
  $('reconnect').addEventListener('click',connect);
  $('clear').addEventListener('click',()=>{if(confirm('Delete locally recorded prediction outcomes?')){state.results=[];try{localStorage.removeItem(storageKey);}catch{}render();}});
  render();connect();
})();
