(() => {
  "use strict";
  // Public market data only. No account token and no trading requests.
  const APP_ID = "1089";
  const WS_URL = `wss://ws.derivws.com/websockets/v3?app_id=${APP_ID}`;
  const $ = (id) => document.getElementById(id);
  const state = { ws:null, requestId:0, pending:new Map(), symbols:[], symbol:"", candles:[], ticks:[], timeframe:60, lastSignal:"", history:loadHistory(), reconnectTimer:null };

  function loadHistory(){ try{return JSON.parse(localStorage.getItem("derivpro_history")||"[]")}catch{return []} }
  function saveHistory(){ try{localStorage.setItem("derivpro_history",JSON.stringify(state.history.slice(0,50)))}catch{} }
  function setConnection(mode,label){$("connectionText").textContent=label;$("connectionDot").parentElement.className="connection "+mode}
  function send(payload){
    if(!state.ws || state.ws.readyState!==WebSocket.OPEN) return Promise.reject(new Error("Not connected"));
    const req_id=++state.requestId; payload.req_id=req_id;
    return new Promise((resolve,reject)=>{state.pending.set(req_id,{resolve,reject});state.ws.send(JSON.stringify(payload));setTimeout(()=>{if(state.pending.has(req_id)){state.pending.delete(req_id);reject(new Error("Market data request timed out"))}},12000)});
  }
  function connect(){
    clearTimeout(state.reconnectTimer); setConnection("","Connecting to Deriv…");
    try{state.ws=new WebSocket(WS_URL)}catch(e){setConnection("offline","Connection unavailable");return}
    state.ws.onopen=async()=>{
      setConnection("online","Connected · public data");
      try{
        const response=await send({active_symbols:"brief",product_type:"basic"});
        const list=(response.active_symbols||[]).filter(x=>x.symbol && (String(x.market||"").toLowerCase().includes("synthetic") || String(x.market_display_name||"").toLowerCase().includes("derived") || /^(R_|1HZ|JD|BOOM|CRASH|STEP|STPRNG|RDBEAR|RDBULL)/i.test(x.symbol)));
        state.symbols=list.length?list:(response.active_symbols||[]).filter(x=>/^(R_|1HZ|JD|BOOM|CRASH|STEP|STPRNG|RDBEAR|RDBULL)/i.test(x.symbol||""));
        populateSymbols();
        if(state.symbols.length){const chosen=state.symbols.find(x=>x.symbol===state.symbol)||state.symbols[0];selectSymbol(chosen.symbol)}
        else setConnection("offline","No synthetic markets returned");
      }catch(e){setConnection("offline","Market list failed");console.error(e)}
    };
    state.ws.onmessage=(event)=>{
      let msg;try{msg=JSON.parse(event.data)}catch{return}
      if(msg.req_id && state.pending.has(msg.req_id)){const p=state.pending.get(msg.req_id);state.pending.delete(msg.req_id);msg.error?p.reject(new Error(msg.error.message)):p.resolve(msg);return}
      if(msg.error){console.warn(msg.error.message);return}
      if(msg.msg_type==="tick" && msg.tick) handleTick(msg.tick);
    };
    state.ws.onerror=()=>setConnection("offline","Connection error");
    state.ws.onclose=()=>{setConnection("offline","Disconnected · retrying");state.reconnectTimer=setTimeout(connect,3500)};
  }
  function populateSymbols(){
    const select=$("symbolSelect");select.innerHTML="";
    state.symbols.forEach(item=>{const opt=document.createElement("option");opt.value=item.symbol;opt.textContent=item.display_name||item.symbol;select.appendChild(opt)});
  }
  async function selectSymbol(symbol){
    if(!symbol)return;state.symbol=symbol;$("symbolSelect").value=symbol;
    $("chartTitle").textContent=(state.symbols.find(x=>x.symbol===symbol)?.display_name||symbol)+" · candles";
    state.candles=[];state.ticks=[];state.lastSignal="";renderChart();
    try{
      const history=await send({ticks_history:symbol,adjust_start_time:1,count:120,end:"latest",granularity:state.timeframe,style:"candles"});
      state.candles=(history.candles||[]).map(c=>({epoch:Number(c.epoch),open:Number(c.open),high:Number(c.high),low:Number(c.low),close:Number(c.close)}));
      renderAll();
      await send({ticks:symbol,subscribe:1});
    }catch(e){console.error(e);$("chartEmpty").textContent="Could not load candles. Tap Refresh data."}
  }
  function handleTick(tick){
    if(tick.symbol!==state.symbol)return;
    const quote=Number(tick.quote);if(!Number.isFinite(quote))return;
    state.ticks.push({quote,epoch:Number(tick.epoch)});state.ticks=state.ticks.slice(-100);
    $("latestQuote").textContent=quote.toFixed(decimalPlaces(quote));
    $("quoteTime").textContent=new Date(Number(tick.epoch)*1000).toLocaleTimeString();
    const bucket=Math.floor(Number(tick.epoch)/state.timeframe)*state.timeframe;
    let last=state.candles[state.candles.length-1];
    if(!last||last.epoch!==bucket){last={epoch:bucket,open:quote,high:quote,low:quote,close:quote};state.candles.push(last);state.candles=state.candles.slice(-120)}
    else{last.high=Math.max(last.high,quote);last.low=Math.min(last.low,quote);last.close=quote}
    renderAll();
  }
  function decimalPlaces(n){const s=String(n);return s.includes(".")?Math.min(6,s.split(".")[1].length):2}
  function ema(values,period){if(values.length<period)return null;const k=2/(period+1);let result=values.slice(0,period).reduce((a,b)=>a+b,0)/period;for(let i=period;i<values.length;i++)result=values[i]*k+result*(1-k);return result}
  function rsi(values,period=14){if(values.length<=period)return null;let gains=0,losses=0;for(let i=values.length-period;i<values.length;i++){const d=values[i]-values[i-1];if(d>0)gains+=d;else losses-=d}if(losses===0)return 100;const rs=(gains/period)/(losses/period);return 100-(100/(1+rs))}
  function analyze(){
    const closes=state.candles.map(c=>c.close);const e9=ema(closes,9),e21=ema(closes,21),rv=rsi(closes);
    $("ema9").textContent=e9==null?"—":e9.toFixed(decimalPlaces(closes.at(-1)||0));
    $("ema21").textContent=e21==null?"—":e21.toFixed(decimalPlaces(closes.at(-1)||0));
    $("rsi14").textContent=rv==null?"—":rv.toFixed(1);
    $("rsiLabel").textContent=rv==null?"Need more candles":rv>70?"Overbought zone":rv<30?"Oversold zone":"Neutral zone";
    let direction="WAIT",reason="Waiting for enough candle data to calculate indicators.",strength="—",trend="Unavailable",momentum="Unavailable";
    if(e9!=null&&e21!=null&&rv!=null){
      const bullish=e9>e21, bearish=e9<e21;trend=bullish?"Bullish":bearish?"Bearish":"Flat";
      momentum=rv>55?"Positive":rv<45?"Negative":"Neutral";
      let score=(bullish?1:bearish?-1:0)+(rv>52?1:rv<48?-1:0)+(closes.at(-1)>closes.at(-2)?1:closes.at(-1)<closes.at(-2)?-1:0);
      if(score>=2){direction="RISE";reason="EMA 9 is above EMA 21 and momentum/last-candle direction support an upward bias."}
      else if(score<=-2){direction="FALL";reason="EMA 9 is below EMA 21 and momentum/last-candle direction support a downward bias."}
      else{reason="Indicators are mixed. Waiting is preferable to forcing a direction."}
      strength=direction==="WAIT"?"Low":Math.abs(score)===3?"Stronger alignment":"Moderate alignment";
    }
    $("trendValue").textContent=trend;$("momentumValue").textContent=momentum;$("strengthValue").textContent=strength;
    const card=$("signalCard");card.className="signal-card "+(direction==="RISE"?"rise":direction==="FALL"?"fall":"neutral");
    card.querySelector(".signal-label").textContent=direction;
    $("signalTitle").textContent=direction==="RISE"?"Upward bias":direction==="FALL"?"Downward bias":"No clear signal";
    $("signalReason").textContent=reason;
    if(direction!=="WAIT"&&direction!==state.lastSignal){addHistory(direction,reason);state.lastSignal=direction}
    return {e9,e21,rv};
  }
  function updateDigits(){
    const quotes=state.ticks.map(t=>t.quote);if(!quotes.length)return;
    const digits=quotes.map(q=>{const s=q.toFixed(decimalPlaces(q));return Number(s.replace(".","").slice(-1))});
    const even=digits.filter(d=>d%2===0).length,odd=digits.length-even,over=digits.filter(d=>d>5).length,under=digits.filter(d=>d<5).length;
    const counts=Array(10).fill(0);digits.forEach(d=>counts[d]++);const common=counts.indexOf(Math.max(...counts));
    $("evenOdd").textContent=even>=odd?"EVEN":"ODD";$("evenOddDetail").textContent=`${even} even · ${odd} odd of ${digits.length}`;
    $("overUnder").textContent=over>=under?"OVER 5":"UNDER 5";$("overUnderDetail").textContent=`${over} over · ${under} under · ${counts[5]} exact 5`;
    $("matchesDiffers").textContent=`${common} · ${counts[common]}×`;
  }
  function addHistory(direction,reason){
    const item={time:new Date().toLocaleString(),market:state.symbol,signal:direction,reason};
    state.history.unshift(item);state.history=state.history.slice(0,50);saveHistory();renderHistory();
  }
  function renderHistory(){
    const body=$("historyBody");body.innerHTML="";
    if(!state.history.length){body.innerHTML='<tr><td colspan="4" class="empty-cell">No signals recorded yet.</td></tr>';return}
    state.history.slice(0,20).forEach(item=>{const tr=document.createElement("tr");const vals=[item.time,item.market,item.signal,item.reason];vals.forEach((v,i)=>{const td=document.createElement("td");td.textContent=v;if(i===2)td.className=item.signal==="RISE"?"badge-rise":"badge-fall";tr.appendChild(td)});body.appendChild(tr)});
  }
  function renderChart(){
    const canvas=$("priceChart"),ctx=canvas.getContext("2d"),rect=canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;
    canvas.width=Math.max(1,Math.floor(rect.width*dpr));canvas.height=Math.max(1,Math.floor(rect.height*dpr));ctx.setTransform(dpr,0,0,dpr,0,0);
    const w=rect.width,h=rect.height;ctx.clearRect(0,0,w,h);
    if(state.candles.length<2){$("chartEmpty").style.display="grid";return}
    $("chartEmpty").style.display="none";
    const data=state.candles.slice(-65),min=Math.min(...data.map(c=>c.low)),max=Math.max(...data.map(c=>c.high)),pad=(max-min)*.12||1,lo=min-pad,hi=max+pad;
    const y=v=>h-18-(v-lo)/(hi-lo)*(h-36),step=w/data.length,cw=Math.max(3,step*.58);
    ctx.strokeStyle="#1e3048";ctx.lineWidth=1;
    for(let i=1;i<5;i++){const yy=h*i/5;ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke()}
    data.forEach((c,i)=>{const x=i*step+step/2,up=c.close>=c.open;ctx.strokeStyle=up?"#25d39a":"#ff6f7d";ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(x,y(c.high));ctx.lineTo(x,y(c.low));ctx.stroke();const top=y(Math.max(c.open,c.close)),bottom=y(Math.min(c.open,c.close));ctx.fillRect(x-cw/2,top,cw,Math.max(1,bottom-top))});
    const closes=state.candles.map(c=>c.close);
    [[9,"#6eb6ff"],[21,"#ffc66d"]].forEach(([period,color])=>{ctx.strokeStyle=color;ctx.lineWidth=1.7;ctx.beginPath();let started=false;closes.slice(-data.length).forEach((_,i)=>{const subset=closes.slice(0,closes.length-data.length+i+1),v=ema(subset,period);if(v==null)return;const x=i*step+step/2;if(!started){ctx.moveTo(x,y(v));started=true}else ctx.lineTo(x,y(v))});ctx.stroke()});
    $("candleCount").textContent=`${data.length} candles`;
  }
  function renderAll(){renderChart();analyze();updateDigits()}
  $("symbolSelect").addEventListener("change",e=>selectSymbol(e.target.value));
  $("timeframeSelect").addEventListener("change",async e=>{state.timeframe=Number(e.target.value);if(state.symbol)await selectSymbol(state.symbol)});
  $("refreshBtn").addEventListener("click",()=>{if(state.symbol)selectSymbol(state.symbol);else connect()});
  $("clearHistoryBtn").addEventListener("click",()=>{state.history=[];saveHistory();renderHistory()});
  window.addEventListener("resize",renderChart);
  renderHistory();connect();
})();