# DerivPro Analyzer

A mobile-friendly, signals-only dashboard for public Deriv synthetic-market data.

## Files
- `index.html` — page structure
- `styles.css` — responsive dark dashboard styling
- `app.js` — public WebSocket market feed, candles, indicators and signal history

## Run it
Upload all three files to the root of your GitHub repository (same folder as README.md). Then enable GitHub Pages:
1. Open the repository's **Settings**.
2. Choose **Pages**.
3. Under Build and deployment, choose **Deploy from a branch**.
4. Select branch `main` and folder `/(root)`, then Save.
5. Wait for the Pages URL to appear.

## Data connection
The app connects to Deriv's public WebSocket API using the example app ID `1089`. If Deriv changes access requirements or the connection is blocked, the connection status will show an error.

## Safety
This is an educational technical-analysis tool, not financial advice. It uses public market data only. It does not request login credentials or account tokens and does not contain proposal, buy, sell or automated-trading functionality. Signals are estimates, not guaranteed outcomes.
